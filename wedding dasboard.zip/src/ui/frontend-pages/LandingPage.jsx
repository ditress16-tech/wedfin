import Homepage from './homepage';

const LandingPage = () => {
  return <Homepage />;
};

export default LandingPage;
